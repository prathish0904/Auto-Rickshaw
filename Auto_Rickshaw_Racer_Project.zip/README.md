# Auto-Rickshaw Road Racer - Android APK Build Guide

This package contains the fully styled mobile web application `racer.html`. To compile this game into a native Android `.apk` file, you can use **Capacitor** (by Ionic) or **Cordova**, which takes less than 5 minutes.

---

### Method 1: Build using Capacitor (Recommended & Fastest)

1. **Install Node.js** on your computer if you haven't already.
2. Open your terminal and run:
   ```bash
   npm init -y
   npm install @capacitor/core @capacitor/cli
   npx cap init "Auto Racer" com.prathish.autoracer --web-dir .
   ```
3. Add the Android platform:
   ```bash
   npm install @capacitor/android
   npx cap add android
   ```
4. Copy your game file (`racer.html` renamed to `index.html`) into the web directory or point Capacitor to it in `capacitor.config.json`.
5. Open Android Studio to build and export the APK:
   ```bash
   npx cap open android
   ```
6. In **Android Studio**:
   - Go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Once complete, click **Locate** to find your ready-to-install `app-debug.apk` file!

---

### Method 2: Online PWA Builders (No Local Setup Required)
You can upload `index.html` to free wrapper tools like **PWABuilder.com** (created by Microsoft) or **Cordova Webapp to APK**, and they will instantly generate the signed `.apk` file for your Motorola phone or Android device.
